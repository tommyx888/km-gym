import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Grif Gym - Komunitná telocvičňa Kuchyňa",
  description: "Grif Gym je komunitná telocvičňa v obci Kuchyňa zameraná na kvalitný silový a kondičný tréning pre rôzne úrovne. Otvorené 24/7.",
  keywords: "gym, telocvičňa, fitness, Kuchyňa, silový tréning, kondičný tréning",
  openGraph: {
    title: "Grif Gym - Komunitná telocvičňa Kuchyňa",
    description: "Komunitná telocvičňa zameraná na kvalitný silový a kondičný tréning",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="sk">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-screen flex flex-col`}
      >
        <Header />
        <main className="flex-grow">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}

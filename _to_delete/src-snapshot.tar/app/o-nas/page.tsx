import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'O nás - Grif Gym',
  description: 'Zistite viac o Grif Gym - komunitnej telocvični v obci Kuchyňa',
};

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-extrabold mb-6 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
            O Grif Gym
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Poznajte našu víziu a hodnoty
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-12">
          <section className="bg-white p-10 rounded-2xl shadow-xl border border-gray-100">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h2 className="text-3xl font-bold text-gray-900">
                Naše poslanie
              </h2>
            </div>
            <p className="text-lg text-gray-700 leading-relaxed mb-4">
              Grif Gym je komunitná telocvičňa v obci Kuchyňa zameraná na kvalitný silový a kondičný tréning pre rôzne úrovne. 
              Nejde o preplnené fitness centrum — kladieme dôraz na pohyb s funkčným zmyslom, bezpečnosť a osobný prístup.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              V našej telocvični nájdu prístup každé vekové kategórie so širokou možnosťou využitia strojov a posilňovacích zariadení.
            </p>
          </section>

          <section>
            <h2 className="text-3xl font-bold mb-8 text-gray-900">
              Naše ciele
            </h2>
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow group">
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg group-hover:scale-110 transition-transform">
                    1
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-3 text-gray-900 group-hover:text-blue-600 transition-colors">
                      Sprístupniť fitness priamo v obci
                    </h3>
                    <p className="text-gray-700 leading-relaxed">
                      Chceme, aby sa ľudia nemuseli presúvať do mesta, aby mohli cvičiť. Fitness má byť dostupný pre každého.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow group">
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-red-600 to-red-700 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg group-hover:scale-110 transition-transform">
                    2
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-3 text-gray-900 group-hover:text-red-600 transition-colors">
                      Podporiť miestnu komunitu
                    </h3>
                    <p className="text-gray-700 leading-relaxed">
                      Grif Gym nie je len telocvičňa, ale aj miesto, kde sa stretáva komunita a podporuje sa navzájom.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow group">
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-700 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg group-hover:scale-110 transition-transform">
                    3
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold mb-3 text-gray-900 group-hover:text-purple-600 transition-colors">
                      Umožniť pravidelné cvičenie
                    </h3>
                    <p className="text-gray-700 leading-relaxed">
                      S 24/7 prístupom môžete cvičiť kedykoľvek vám to vyhovuje, bez obmedzení otváracích hodín.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-gradient-to-br from-gray-900 via-gray-800 to-black text-white p-10 rounded-2xl shadow-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:24px_24px]"></div>
            <div className="relative z-10">
              <h2 className="text-3xl font-bold mb-8 text-center">
                Naše hodnoty
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl border border-white/10 hover:bg-white/10 transition-colors">
                  <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-blue-400">
                    Bezpečnosť
                  </h3>
                  <p className="text-gray-300 leading-relaxed">
                    Všetky naše stroje a zariadenia sú pravidelne kontrolované a udržiavané. Bezpečnosť našich členov je na prvom mieste.
                  </p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl border border-white/10 hover:bg-white/10 transition-colors">
                  <div className="w-12 h-12 bg-red-600/20 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-red-400">
                    Osobný prístup
                  </h3>
                  <p className="text-gray-300 leading-relaxed">
                    Nie sme preplnené fitness centrum. Každý člen dostáva osobnú pozornosť a podporu.
                  </p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl border border-white/10 hover:bg-white/10 transition-colors">
                  <div className="w-12 h-12 bg-purple-600/20 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-purple-400">
                    Funkčný pohyb
                  </h3>
                  <p className="text-gray-300 leading-relaxed">
                    Zameriame sa na pohyb s funkčným zmyslom, ktorý pomáha v každodennom živote.
                  </p>
                </div>
                <div className="bg-white/5 backdrop-blur-sm p-6 rounded-xl border border-white/10 hover:bg-white/10 transition-colors">
                  <div className="w-12 h-12 bg-green-600/20 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-green-400">
                    Komunita
                  </h3>
                  <p className="text-gray-300 leading-relaxed">
                    Vytvárame prostredie, kde sa ľudia cítia vítaní a podporovaní v ich fitness cestách.
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section className="text-center p-10 bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-2xl shadow-2xl">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h2 className="text-3xl font-bold mb-4">
              Otváracie hodiny
            </h2>
            <p className="text-5xl font-extrabold mb-2">
              24/7
            </p>
            <p className="text-xl opacity-90">
              Cvičte kedykoľvek vám to vyhovuje
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}



import type { Metadata } from 'next';
import Gallery from '@/components/Gallery';

export const metadata: Metadata = {
  title: 'Galéria - Grif Gym',
  description: 'Pozrite si fotky našej telocvične, strojov a vybavenia',
};

const galleryImages = [
  {
    src: '/images/gym-main-1.jpg',
    alt: 'Hlavná telocvičňa Grif Gym',
    category: 'Hlavná telocvičňa',
  },
  {
    src: '/images/gym-main-2.jpg',
    alt: 'Posilňovňa s vybavením',
    category: 'Hlavná telocvičňa',
  },
  {
    src: '/images/equipment-1.jpg',
    alt: 'Posilňovacie stroje',
    category: 'Stroje a vybavenie',
  },
  {
    src: '/images/equipment-2.jpg',
    alt: 'Funkčné tréningové zóny',
    category: 'Cvičebné zóny',
  },
  {
    src: '/images/zones-1.jpg',
    alt: 'Cvičebná zóna',
    category: 'Cvičebné zóny',
  },
  {
    src: '/images/zones-2.jpg',
    alt: 'Tréningová plocha',
    category: 'Cvičebné zóny',
  },
];

export default function GalleryPage() {
  return (
    <div className="min-h-screen bg-[#ffffff] py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-[#000000]">
            Galéria
          </h1>
          <div className="w-24 h-1 bg-[#0066ff] mx-auto mb-4"></div>
          <p className="text-lg text-[#1a1a1a] max-w-2xl mx-auto">
            Pozrite si naše priestory, stroje a vybavenie. Grif Gym ponúka moderné zariadenia pre všetky typy tréningov.
          </p>
        </div>

        <Gallery images={galleryImages} />

        <div className="max-w-3xl mx-auto mt-16 bg-[#e5e5e5] p-8 rounded-lg">
          <h2 className="text-2xl font-bold mb-4 text-[#000000]">
            Viac fotiek
          </h2>
          <p className="text-[#1a1a1a] mb-4">
            Pre viac fotiek a aktualizácie nás sledujte na sociálnych sieťach:
          </p>
          <div className="flex gap-4">
            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#0066ff] hover:bg-blue-600 text-[#ffffff] px-6 py-3 rounded-lg font-semibold transition-colors duration-200"
            >
              Facebook
            </a>
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#ff0000] hover:bg-red-600 text-[#ffffff] px-6 py-3 rounded-lg font-semibold transition-colors duration-200"
            >
              Instagram
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}




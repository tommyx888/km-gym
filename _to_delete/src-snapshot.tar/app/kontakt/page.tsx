import type { Metadata } from 'next';
import GoogleMap from '@/components/GoogleMap';

export const metadata: Metadata = {
  title: 'Kontakt - Grif Gym',
  description: 'Kontaktujte Grif Gym - komunitnú telocvičňu v obci Kuchyňa',
};

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-[#ffffff] py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-[#000000]">
            Kontakt
          </h1>
          <div className="w-24 h-1 bg-[#0066ff] mx-auto mb-4"></div>
          <p className="text-lg text-[#1a1a1a] max-w-2xl mx-auto">
            Kontaktujte nás telefónom, emailom alebo nás navštívte osobne. Tešíme sa na vás!
          </p>
        </div>

        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-[#000000]">
                Kontaktné informácie
              </h2>
            </div>

            <div className="bg-[#e5e5e5] p-6 rounded-lg">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 bg-[#0066ff] rounded-full flex items-center justify-center text-[#ffffff] text-xl mr-4">
                  📞
                </div>
                <h3 className="text-xl font-semibold text-[#000000]">Telefón</h3>
              </div>
              <a
                href="tel:0915428554"
                className="text-lg text-[#0066ff] hover:text-blue-600 transition-colors"
              >
                0915428554
              </a>
            </div>

            <div className="bg-[#e5e5e5] p-6 rounded-lg">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 bg-[#ff0000] rounded-full flex items-center justify-center text-[#ffffff] text-xl mr-4">
                  ✉️
                </div>
                <h3 className="text-xl font-semibold text-[#000000]">Email</h3>
              </div>
              <a
                href="mailto:kovanicpeter@gmail.com"
                className="text-lg text-[#ff0000] hover:text-red-600 transition-colors break-all"
              >
                kovanicpeter@gmail.com
              </a>
            </div>

            <div className="bg-[#e5e5e5] p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-[#1a1a1a] rounded-full flex items-center justify-center text-[#ffffff] text-xl mr-4">
                  🌐
                </div>
                <h3 className="text-xl font-semibold text-[#000000]">Sociálne siete</h3>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#0066ff] hover:bg-blue-600 text-[#ffffff] px-6 py-3 rounded-lg font-semibold text-center transition-colors duration-200"
                >
                  Facebook
                </a>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-[#ff0000] hover:bg-red-600 text-[#ffffff] px-6 py-3 rounded-lg font-semibold text-center transition-colors duration-200"
                >
                  Instagram
                </a>
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#0066ff] to-blue-600 text-[#ffffff] p-6 rounded-lg">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 bg-[#ffffff]/20 rounded-full flex items-center justify-center text-[#ffffff] text-xl mr-4">
                  🕐
                </div>
                <h3 className="text-xl font-semibold">Otváracie hodiny</h3>
              </div>
              <p className="text-2xl font-bold">24/7</p>
              <p className="text-[#e5e5e5] mt-2">
                Cvičte kedykoľvek vám to vyhovuje
              </p>
            </div>

            <div className="bg-[#e5e5e5] p-6 rounded-lg">
              <div className="flex items-center mb-3">
                <div className="w-12 h-12 bg-[#000000] rounded-full flex items-center justify-center text-[#ffffff] text-xl mr-4">
                  📍
                </div>
                <h3 className="text-xl font-semibold text-[#000000]">Adresa</h3>
              </div>
              <p className="text-lg text-[#1a1a1a]">
                Kuchyňa, Slovensko
              </p>
            </div>
          </div>

          <div>
            <h2 className="text-3xl font-bold mb-6 text-[#000000]">
              Kde nás nájdete
            </h2>
            <GoogleMap address="Kuchyňa, Slovakia" />
            <div className="mt-6 bg-[#e5e5e5] p-6 rounded-lg">
              <h3 className="text-lg font-semibold mb-3 text-[#000000]">
                Ako sa k nám dostať
              </h3>
              <p className="text-[#1a1a1a]">
                Grif Gym sa nachádza v obci Kuchyňa. Pre presnú adresu a navigáciu použite mapu vyššie alebo nás kontaktujte telefónom.
              </p>
            </div>
          </div>
        </div>

        <div className="max-w-3xl mx-auto mt-16 text-center bg-gradient-to-br from-[#1a1a1a] to-[#000000] text-[#ffffff] p-8 rounded-lg">
          <h2 className="text-2xl font-bold mb-4">Máte otázky?</h2>
          <p className="text-[#e5e5e5] mb-6">
            Neváhajte nás kontaktovať. Radi vám odpovieme na všetky vaše otázky.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:0915428554"
              className="bg-[#0066ff] hover:bg-blue-600 text-[#ffffff] px-8 py-4 rounded-lg font-semibold transition-colors duration-200"
            >
              Zavolať teraz
            </a>
            <a
              href="mailto:kovanicpeter@gmail.com"
              className="bg-[#ff0000] hover:bg-red-600 text-[#ffffff] px-8 py-4 rounded-lg font-semibold transition-colors duration-200"
            >
              Poslať email
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}




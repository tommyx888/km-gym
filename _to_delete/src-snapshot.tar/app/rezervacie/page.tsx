'use client';

import ReservationForm from '@/components/ReservationForm';

export default function ReservationsPage() {
  const handleSubmit = async (data: {
    name: string;
    email: string;
    phone?: string;
    date: string;
    time: string;
  }) => {
    const response = await fetch('/rezervacie/api', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Chyba pri odosielaní rezervácie');
    }

    return response.json();
  };

  return (
    <div className="min-h-screen bg-[#ffffff] py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-[#000000]">
            Rezervácie
          </h1>
          <div className="w-24 h-1 bg-[#0066ff] mx-auto mb-4"></div>
          <p className="text-lg text-[#1a1a1a] max-w-2xl mx-auto">
            Rezervujte si čas na tréning. Vyplňte formulár a my sa vám ozveme na potvrdenie rezervácie.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="bg-[#e5e5e5] p-8 rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold mb-6 text-[#000000]">
              Rezervačný formulár
            </h2>
            <ReservationForm onSubmit={handleSubmit} />
          </div>

          <div className="mt-8 bg-gradient-to-br from-[#1a1a1a] to-[#000000] text-[#ffffff] p-8 rounded-lg">
            <h3 className="text-xl font-bold mb-4">Dôležité informácie</h3>
            <ul className="space-y-3 text-[#e5e5e5]">
              <li className="flex items-start">
                <span className="mr-3">✓</span>
                <span>Rezervácie sú potrebné najmä pre jednorazové vstupy</span>
              </li>
              <li className="flex items-start">
                <span className="mr-3">✓</span>
                <span>Mesační členovia majú 24/7 prístup bez rezervácie</span>
              </li>
              <li className="flex items-start">
                <span className="mr-3">✓</span>
                <span>Po odoslaní rezervácie vás budeme kontaktovať na potvrdenie</span>
              </li>
              <li className="flex items-start">
                <span className="mr-3">✓</span>
                <span>V prípade otázok nás kontaktujte na telefóne alebo emaile</span>
              </li>
            </ul>
          </div>

          <div className="mt-8 text-center">
            <p className="text-[#1a1a1a] mb-4">
              Potrebujete pomoc s rezerváciou?
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="tel:0915428554"
                className="bg-[#0066ff] hover:bg-blue-600 text-[#ffffff] px-6 py-3 rounded-lg font-semibold transition-colors duration-200"
              >
                📞 0915428554
              </a>
              <a
                href="mailto:kovanicpeter@gmail.com"
                className="bg-[#ff0000] hover:bg-red-600 text-[#ffffff] px-6 py-3 rounded-lg font-semibold transition-colors duration-200"
              >
                ✉️ Email
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}




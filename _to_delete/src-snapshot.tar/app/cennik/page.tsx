import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'Cenník - Grif Gym',
  description: 'Cenník členstva a vstupov do Grif Gym',
};

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-extrabold mb-6 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
            Cenník
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            Vyberte si balíček, ktorý vám najlepšie vyhovuje. Všetky členstvá zahŕňajú 24/7 prístup.
          </p>
        </div>

        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white p-10 rounded-2xl shadow-2xl transform hover:scale-105 transition-all duration-300 overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32"></div>
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full -ml-24 -mb-24"></div>
            <div className="relative z-10">
              <div className="text-center mb-8">
                <div className="text-6xl font-extrabold mb-2">30€</div>
                <div className="text-xl opacity-90 font-medium">mesačne</div>
              </div>
              <h2 className="text-3xl font-bold mb-6 text-center">Mesačné členstvo</h2>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center">
                <svg className="w-5 h-5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Neobmedzený prístup 24/7
              </li>
              <li className="flex items-center">
                <svg className="w-5 h-5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Všetky stroje a zariadenia
              </li>
              <li className="flex items-center">
                <svg className="w-5 h-5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Komunitná podpora
              </li>
              <li className="flex items-center">
                <svg className="w-5 h-5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Bez zmluvy
              </li>
            </ul>
            <Link
              href="/rezervacie"
              className="block w-full bg-white text-blue-600 text-center py-4 rounded-xl font-bold text-lg hover:bg-gray-50 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Začať teraz
            </Link>
          </div>
          </div>

          <div className="relative bg-gradient-to-br from-red-500 via-red-600 to-red-700 text-white p-10 rounded-2xl shadow-2xl transform hover:scale-105 transition-all duration-300 overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32"></div>
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full -ml-24 -mb-24"></div>
            <div className="relative z-10">
              <div className="text-center mb-8">
                <div className="text-6xl font-extrabold mb-2">3€</div>
                <div className="text-xl opacity-90 font-medium">jednorazovo</div>
              </div>
              <h2 className="text-3xl font-bold mb-6 text-center">Jednorazový vstup</h2>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center">
                <svg className="w-5 h-5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Jeden deň prístupu
              </li>
              <li className="flex items-center">
                <svg className="w-5 h-5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Všetky stroje a zariadenia
              </li>
              <li className="flex items-center">
                <svg className="w-5 h-5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Ideálne na vyskúšanie
              </li>
              <li className="flex items-center">
                <svg className="w-5 h-5 mr-3 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Bez záväzkov
              </li>
            </ul>
            <Link
              href="/rezervacie"
              className="block w-full bg-white text-red-600 text-center py-4 rounded-xl font-bold text-lg hover:bg-gray-50 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105"
            >
              Rezervovať
            </Link>
          </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto bg-white p-10 rounded-2xl shadow-xl border border-gray-100">
          <h2 className="text-2xl font-bold mb-4 text-[#000000]">
            Často kladené otázky
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-2 text-[#000000]">
                Môžem zrušiť členstvo kedykoľvek?
              </h3>
              <p className="text-[#1a1a1a]">
                Áno, naše mesačné členstvo je bez zmluvy. Môžete zrušiť kedykoľvek bez poplatkov.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2 text-[#000000]">
                Ako funguje platba?
              </h3>
              <p className="text-[#1a1a1a]">
                Mesačné členstvo sa platí vopred každý mesiac. Jednorazový vstup sa platí pri príchode.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2 text-[#000000]">
                Potrebujem rezerváciu?
              </h3>
              <p className="text-[#1a1a1a]">
                Pre mesačné členstvo nie je rezervácia potrebná - prístup je 24/7. Pre jednorazový vstup odporúčame rezerváciu.
              </p>
            </div>
          </div>
        </div>

        <div className="max-w-3xl mx-auto mt-12 text-center">
          <p className="text-lg text-[#1a1a1a] mb-6">
            Máte otázky? Kontaktujte nás
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:0915428554"
              className="bg-[#0066ff] hover:bg-blue-600 text-[#ffffff] px-8 py-4 rounded-lg font-semibold transition-colors duration-200"
            >
              📞 0915428554
            </a>
            <a
              href="mailto:kovanicpeter@gmail.com"
              className="bg-[#ff0000] hover:bg-red-600 text-[#ffffff] px-8 py-4 rounded-lg font-semibold transition-colors duration-200"
            >
              ✉️ Email
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}



-- Create reservations table
CREATE TABLE IF NOT EXISTS reservations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  date DATE NOT NULL,
  time TIME NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Create index for faster date queries
CREATE INDEX IF NOT EXISTS idx_reservations_date ON reservations(date);

-- Enable Row Level Security (RLS)
ALTER TABLE reservations ENABLE ROW LEVEL SECURITY;

-- Create policy to allow inserts (public can create reservations)
CREATE POLICY "Allow public inserts" ON reservations
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create policy to allow reads (optional - for checking availability)
CREATE POLICY "Allow public reads" ON reservations
  FOR SELECT
  TO public
  USING (true);




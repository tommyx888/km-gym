'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const reservationSchema = z.object({
  name: z.string().min(2, 'Meno musí mať aspoň 2 znaky'),
  email: z.string().email('Neplatná emailová adresa'),
  phone: z.string().optional(),
  date: z.string().min(1, 'Vyberte dátum'),
  time: z.string().min(1, 'Vyberte čas'),
});

type ReservationFormData = z.infer<typeof reservationSchema>;

interface ReservationFormProps {
  onSubmit: (data: ReservationFormData) => Promise<void>;
}

export default function ReservationForm({ onSubmit }: ReservationFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'success' | 'error' | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<ReservationFormData>({
    resolver: zodResolver(reservationSchema),
  });

  const onFormSubmit = async (data: ReservationFormData) => {
    setIsSubmitting(true);
    setSubmitStatus(null);

    try {
      await onSubmit(data);
      setSubmitStatus('success');
      reset();
    } catch (error) {
      setSubmitStatus('error');
      console.error('Error submitting reservation:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const today = new Date().toISOString().split('T')[0];
  const timeSlots = Array.from({ length: 17 }, (_, i) => {
    const hour = 6 + i;
    return `${hour.toString().padStart(2, '0')}:00`;
  });

  return (
    <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-6">
      <div>
        <label htmlFor="name" className="block text-sm font-semibold mb-2 text-[#000000]">
          Meno a priezvisko *
        </label>
        <input
          type="text"
          id="name"
          {...register('name')}
          className="w-full px-4 py-3 border border-[#e5e5e5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066ff] focus:border-transparent"
          placeholder="Ján Novák"
        />
        {errors.name && (
          <p className="mt-1 text-sm text-[#ff0000]">{errors.name.message}</p>
        )}
      </div>

      <div>
        <label htmlFor="email" className="block text-sm font-semibold mb-2 text-[#000000]">
          Email *
        </label>
        <input
          type="email"
          id="email"
          {...register('email')}
          className="w-full px-4 py-3 border border-[#e5e5e5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066ff] focus:border-transparent"
          placeholder="jan.novak@example.com"
        />
        {errors.email && (
          <p className="mt-1 text-sm text-[#ff0000]">{errors.email.message}</p>
        )}
      </div>

      <div>
        <label htmlFor="phone" className="block text-sm font-semibold mb-2 text-[#000000]">
          Telefón (voliteľné)
        </label>
        <input
          type="tel"
          id="phone"
          {...register('phone')}
          className="w-full px-4 py-3 border border-[#e5e5e5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066ff] focus:border-transparent"
          placeholder="0915428554"
        />
        {errors.phone && (
          <p className="mt-1 text-sm text-[#ff0000]">{errors.phone.message}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="date" className="block text-sm font-semibold mb-2 text-[#000000]">
            Dátum *
          </label>
          <input
            type="date"
            id="date"
            {...register('date')}
            min={today}
            className="w-full px-4 py-3 border border-[#e5e5e5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066ff] focus:border-transparent"
          />
          {errors.date && (
            <p className="mt-1 text-sm text-[#ff0000]">{errors.date.message}</p>
          )}
        </div>

        <div>
          <label htmlFor="time" className="block text-sm font-semibold mb-2 text-[#000000]">
            Čas *
          </label>
          <select
            id="time"
            {...register('time')}
            className="w-full px-4 py-3 border border-[#e5e5e5] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0066ff] focus:border-transparent"
          >
            <option value="">Vyberte čas</option>
            {timeSlots.map((time) => (
              <option key={time} value={time}>
                {time}
              </option>
            ))}
          </select>
          {errors.time && (
            <p className="mt-1 text-sm text-[#ff0000]">{errors.time.message}</p>
          )}
        </div>
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-[#0066ff] hover:bg-blue-600 text-[#ffffff] py-4 rounded-lg font-semibold text-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isSubmitting ? 'Odosielanie...' : 'Rezervovať'}
      </button>

      {submitStatus === 'success' && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg">
          <p className="font-semibold">Rezervácia bola úspešne odoslaná!</p>
          <p className="text-sm mt-1">Ozveme sa vám čoskoro na potvrdenie.</p>
        </div>
      )}

      {submitStatus === 'error' && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg">
          <p className="font-semibold">Chyba pri odosielaní rezervácie</p>
          <p className="text-sm mt-1">Skúste to prosím znova alebo nás kontaktujte priamo.</p>
        </div>
      )}
    </form>
  );
}




'use client';

import Image from 'next/image';
import { useState } from 'react';

interface GalleryProps {
  images: Array<{
    src: string;
    alt: string;
    category?: string;
  }>;
}

export default function Gallery({ images }: GalleryProps) {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const openLightbox = (index: number) => {
    setSelectedImage(index);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'unset';
  };

  const navigateImage = (direction: 'prev' | 'next') => {
    if (selectedImage === null) return;
    
    if (direction === 'prev') {
      setSelectedImage(selectedImage > 0 ? selectedImage - 1 : images.length - 1);
    } else {
      setSelectedImage(selectedImage < images.length - 1 ? selectedImage + 1 : 0);
    }
  };

  const groupedImages = images.reduce((acc, image, index) => {
    const category = image.category || 'Všetky';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push({ ...image, index });
    return acc;
  }, {} as Record<string, Array<{ src: string; alt: string; index: number }>>);

  const categories = Object.keys(groupedImages);
  const [selectedCategory, setSelectedCategory] = useState<string>('Všetky');

  const displayImages = selectedCategory === 'Všetky' 
    ? images.map((img, idx) => ({ ...img, index: idx }))
    : groupedImages[selectedCategory] || [];

  return (
    <>
      {categories.length > 1 && (
        <div className="flex flex-wrap gap-4 justify-center mb-8">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-2 rounded-lg font-semibold transition-colors duration-200 ${
                selectedCategory === category
                  ? 'bg-[#0066ff] text-[#ffffff]'
                  : 'bg-[#e5e5e5] text-[#000000] hover:bg-[#0066ff] hover:text-[#ffffff]'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {displayImages.map((image) => (
          <div
            key={image.index}
            className="relative aspect-square overflow-hidden rounded-lg cursor-pointer group shadow-lg hover:shadow-xl transition-shadow duration-200"
            onClick={() => openLightbox(image.index)}
          >
            <Image
              src={image.src}
              alt={image.alt}
              fill
              className="object-cover group-hover:scale-110 transition-transform duration-300"
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-200"></div>
          </div>
        ))}
      </div>

      {selectedImage !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 text-[#ffffff] hover:text-[#ff0000] transition-colors z-10"
            aria-label="Zatvoriť"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              navigateImage('prev');
            }}
            className="absolute left-4 text-[#ffffff] hover:text-[#0066ff] transition-colors z-10"
            aria-label="Predchádzajúci"
          >
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              navigateImage('next');
            }}
            className="absolute right-4 text-[#ffffff] hover:text-[#0066ff] transition-colors z-10"
            aria-label="Ďalší"
          >
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>

          <div
            className="relative max-w-7xl max-h-full"
            onClick={(e) => e.stopPropagation()}
          >
            <Image
              src={images[selectedImage].src}
              alt={images[selectedImage].alt}
              width={1200}
              height={800}
              className="max-w-full max-h-[90vh] object-contain"
              priority
            />
            <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-[#ffffff] text-center">
              <p className="bg-black/50 px-4 py-2 rounded-lg">
                {selectedImage + 1} / {images.length}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}




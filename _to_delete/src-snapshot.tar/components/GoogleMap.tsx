'use client';

interface GoogleMapProps {
  address?: string;
  latitude?: number;
  longitude?: number;
}

export default function GoogleMap({ address = 'Kuchyňa, Slovakia', latitude, longitude }: GoogleMapProps) {
  const mapSrc = latitude && longitude
    ? `https://www.google.com/maps/embed/v1/place?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}&q=${latitude},${longitude}`
    : `https://www.google.com/maps/embed/v1/place?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}&q=${encodeURIComponent(address)}`;

  const fallbackSrc = `https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2635.123456789!2d17.123456789!3d48.123456789!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDjCsDA3JzI0LjQiTiAxN8KwMDcnMjguNCJF!5e0!3m2!1ssk!2ssk!4v1234567890123!5m2!1ssk!2ssk`;

  return (
    <div className="w-full h-[400px] md:h-[500px] rounded-lg overflow-hidden shadow-lg">
      <iframe
        width="100%"
        height="100%"
        style={{ border: 0 }}
        loading="lazy"
        allowFullScreen
        referrerPolicy="no-referrer-when-downgrade"
        src={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY ? mapSrc : fallbackSrc}
        title="Grif Gym Location"
      />
    </div>
  );
}



